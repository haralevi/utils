const doc = document;
const wnd = window;

const isLocal = () => (wnd.location.href.indexOf('localhost') !== -1);

const log = (...arg) => {
    if (isLocal())
        console.log(...arg)
};

/**
 * waitForFinalEvent - is used for delayed window resize event
 */
const waitForFinalEvent = (function () {
    let timers = {};
    return function (callback, ms, uniqueId) {
        if (!uniqueId) {
            uniqueId = 'Don\'t call this twice without a uniqueId';
        }
        if (timers[uniqueId]) {
            clearTimeout(timers[uniqueId]);
        }
        timers[uniqueId] = setTimeout(callback, ms);
    };
})();

/**
 * Equivalent for jquery ready
 */
const ready = function (fn) {
    if (document.attachEvent ? document.readyState === 'complete' : document.readyState !== 'loading') {
        fn();
    } else {
        document.addEventListener('DOMContentLoaded', fn);
    }
};

/**
 * Module for DOM manipulation
 */
const utils = {

    wndH: () => {
        const body = document.body;
        const html = document.documentElement;

        return Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);
    },

    wndW: () => {
        const body = document.body;
        const html = document.documentElement;

        return Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth);
    },

    isMac: () => {
        return navigator.platform.indexOf('Mac') !== -1;
    },

    isTouch: function () {
        return (('ontouchstart' in window) || window.DocumentTouch && document instanceof DocumentTouch)
    },

    isInViewport: function (el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
            rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
        );
    },

    get: (el) => {
        return doc.getElementById(el);
    },

    getIn: (el, context) => {
        return context.querySelector('#' + el);
    },

    sel: (el) => {
        return doc.querySelector(el);
    },

    selIn: (el, context) => {
        return context.querySelector(el);
    },

    selAll: (el) => {
        return doc.querySelectorAll(el);
    },

    selAllIn: (el, context) => {
        return context.querySelectorAll(el);
    },

    trigger: (el, e) => {
        const event = document.createEvent('HTMLEvents');
        event.initEvent(e, true, false);
        el.dispatchEvent(event);
    },

    fadeIn: (el) => {
        el.style.opacity = 0;
        let last = +new Date();
        const tick = () => {
            el.style.opacity = +el.style.opacity + (new Date() - last) / 400;
            last = +new Date();
            if (+el.style.opacity < 1)
                (wnd.requestAnimationFrame && requestAnimationFrame(tick)) || setTimeout(tick, 16);
        };
        tick();
    },

    addClass: (el, className) => {
        if (el.classList)
            el.classList.add(className);
        else
            el.className += ' ' + className;
    },

    removeClass: (el, className) => {
        if (el.classList)
            el.classList.remove(className);
        else
            el.className = el.className.replace(new RegExp('(^|\\b)' + className.split(' ').join('|') + '(\\b|$)', 'gi'), ' ');
    },

    is: (el, selector) => {
        return (el.matches || el.matchesSelector || el.msMatchesSelector || el.mozMatchesSelector || el.webkitMatchesSelector || el.oMatchesSelector).call(el, selector);
    },

    show: (el) => {
        el.style.display = '';
    },

    hide: (el) => {
        el.style.display = 'none';
    },

    isHidden: (el) => {
        return (el.style.display === 'none');
    },

    html: (el, html) => {
        el.innerHTML = utils.stripDangerousTags(html);
    },

    stripTags: (html) => {
        const tmp = document.createElement('DIV');
        utils.html(tmp, html);
        return tmp.textContent.trim() || tmp.innerText.trim() || '';
    },

    stripDangerousTags: (html) => {
        if (html)
            html = html.replace(/< *\/? *script *>/g, '').replace(/< *\/? *iframe *>/g, '');
        return html;
    },

    nl2br: (html) => {
        if (html)
            html = html.replace(/(?:\r\n|\r|\n)/g, '<br />');
        return html;
    },

    animate: (el, type = 'flash', isColored = false, className = '') => {
        let animateClass = 'animated__' + type;
        if (isColored)
            animateClass += '__colored';
        utils.addClass(el, animateClass);
        setTimeout(() => {
            utils.removeClass(el, animateClass);
            if (className !== '')
                utils.addClass(el, className);
        }, 900);
    },

    updateByElementVal: (el, val, animationType = '', isColored = false, className = '') => {
        let isChanged = false;

        if (!el)
            return isChanged;

        if (typeof val !== 'string')
            val = val.toString();
        val = val.trim();
        if (el && el.innerHTML.trim().replace(/[\r\n ]/g, '') !== val.replace(/[\r\n ]/g, '')) {
            isChanged = true;
            utils.html(el, val);
            if (animationType !== '')
                utils.animate(el, animationType, isColored);
            else if (className !== '')
                utils.addClass(el, className);
        }
        return isChanged;
    },

    updateByElementAttr: (el, val, attr, animationType = '', isColored = false, className = '') => {
        let isChanged = false;

        if (!el)
            return isChanged;

        if (typeof val !== 'string')
            val = val.toString();
        val = val.trim();
        if (el && el.getAttribute(attr) && el.getAttribute(attr).trim().replace(/[\r\n ]/g, '') !== val.replace(/[\r\n ]/g, '')) {
            isChanged = true;
            el.setAttribute(attr, val);
            if (animationType !== '')
                utils.animate(el, animationType, isColored);
            else if (className !== '')
                utils.addClass(el, className);
        }
        return isChanged;
    },

    blink: (el, className = '', speed = 500) => {
        if (className !== '')
            utils.addClass(el, className);
        else
            el.style.visibility = 'hidden';
        setTimeout(() => {
            if (className !== '')
                utils.removeClass(el, className);
            else
                el.style.visibility = 'visible';
            setTimeout(() => {
                if (className !== '')
                    utils.addClass(el, className);
                else
                    el.style.visibility = 'hidden';
                setTimeout(() => {
                    if (className !== '')
                        utils.removeClass(el, className);
                    else
                        el.style.visibility = 'visible';
                }, speed);
            }, speed)
        }, speed);
    },

    round: (value, step) => {
        step || (step = 1.0);
        let inv = 1.0 / step;
        return Math.round(value * inv) / inv;
    },

    copyToClipboard: (text) => {
        if (window.clipboardData && window.clipboardData.setData) {
            // IE specific code path to prevent textarea being shown while dialog is visible.
            return clipboardData.setData("Text", text);

        } else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
            const textarea = document.createElement("textarea");
            textarea.textContent = text;
            textarea.style.position = "fixed";  // Prevent scrolling to bottom of page in MS Edge.
            document.body.appendChild(textarea);
            textarea.select();
            try {
                return document.execCommand("copy");  // Security exception may be thrown by some browsers.
            } catch (ex) {
                console.warn("Copy to clipboard failed.", ex);
                return false;
            } finally {
                document.body.removeChild(textarea);
            }
        }
    },

    linkify: (text, isBlank = true) => {
        if (text) {
            text = text.replace(
                /((https?\:\/\/)|(www\.))(\S+)(\w+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@\-\/]))?/gi,
                function(url){
                    let full_url = url;
                    if (!full_url.match('^https?:\/\/')) {
                        full_url = 'http://' + full_url;
                    }
                    let target = '';
                    if(isBlank)
                        target = ' target="_blank"';
                    return '<a href="' + full_url + '"' + target + '>' + url + '</a>';
                }
            );
        }
        return text;
    }
};

/* global elements and variables ***************************************/
const pageType = utils.sel('body').getAttribute('data-page-type');
const layout = utils.sel('.mdl-layout__content');
const indexHeader = utils.get('index-header');
/* /global elements and variables ***************************************/

export {
    doc,
    wnd,
    isLocal,
    log,
    utils,
    ready,
    waitForFinalEvent,
    pageType,
    layout,
    indexHeader,
};

