import {utils} from './utils';

/* Handle drop down menus ***************************************/
/**
 * Triggers click on menu item
 */
const showDropDownMenu = function () {
    utils.trigger(this, 'click');
};

const menuPhotoEdit = utils.get('header-menu--photo-edit');
menuPhotoEdit.addEventListener('mouseenter', showDropDownMenu);

const menuBusinessSolution = utils.get('header-menu--business-solution');
menuBusinessSolution.addEventListener('mouseenter', showDropDownMenu);

const menuLanguage = utils.get('header-menu--language');
menuLanguage.addEventListener('mouseenter', showDropDownMenu);

/**
 * Handles hiding of drop down menu, on mouse leave event with timeout
 */
const handleDropDownMenu = function (el, timeout = 500) {
    let isOver = false;
    el.addEventListener('mouseleave', function () {
        isOver = false;
        const elParent = this.parentNode;
        setTimeout(function () {
            if (!isOver)
                utils.removeClass(elParent, 'is-visible');
        }, timeout);
    });
    el.addEventListener('mouseover', function () {
        isOver = true;
    });
};

const menuPhotoEditList = utils.get('header-menu--photo-edit--list');
if (menuPhotoEditList)
    handleDropDownMenu(menuPhotoEditList);

const menuBusinessSolutionList = utils.get('header-menu--business-solution--list');
if (menuBusinessSolutionList)
    handleDropDownMenu(menuBusinessSolutionList);
