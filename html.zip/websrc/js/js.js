import '../scss/css.scss';

//import {autoInit, base, checkbox, dialog, drawer, formField, gridList, iconToggle, linearProgress, menu, radio, ripple, select, selectionControl, slider, snackbar, tabs, textField, toolbar} from '../../node_modules/material-components-web';
//import * as mdc from '../../node_modules/material-components-web';
//mdc.autoInit();

import {layout, log, indexHeader, utils} from './utils';
import './dropdown';

/* Layout scroll ***************************************/
const indexPageScrollDown = utils.get('index-page--scroll');
/**
 * Handle layout scroll, because window is never scrolled in material.js layout
 */
const handleLayoutScroll = function () {
    let scrollTop = this.scrollTop;
    //log('scrollTop:', scrollTop);
    if (scrollTop > 100) {
        utils.addClass(indexHeader, 'index-header__fixed');
        if(indexPageScrollDown)
            utils.hide(indexPageScrollDown);
    }
    else {
        utils.removeClass(indexHeader, 'index-header__fixed');
        if(indexPageScrollDown)
            utils.show(indexPageScrollDown);
    }
};

if (layout)
    layout.addEventListener('scroll', handleLayoutScroll);
/* /Layout scroll ***************************************/

/* index page cover scroll down ***************************************/
const indexPageTwo = utils.get('index-page--two');
const handleIndexPageScrollDown = function () {
    utils.hide(indexPageScrollDown);
    utils.addClass(indexHeader, 'index-header__fixed');
    setTimeout(() => {
        layout.scrollTop = indexPageTwo.offsetTop - indexHeader.offsetHeight;
    }, 400);
};


if (indexPageScrollDown)
    indexPageScrollDown.addEventListener('click', handleIndexPageScrollDown);
/* /index page cover scroll down ***************************************/

/* handle register form ***************************************/
let isAddInvoiceAddressBlk = false;
const handleSeeMoreLinkRegisterClick = function (e) {
    e.preventDefault();
    const addInvoiceAddressBlk = utils.get('add-invoice-address--blk');
    if(!isAddInvoiceAddressBlk) {
        utils.show(addInvoiceAddressBlk);
        utils.fadeIn(addInvoiceAddressBlk);
    }
    else {
        utils.hide(addInvoiceAddressBlk);
        addInvoiceAddressBlk.style.opacity = 0;
    }
    isAddInvoiceAddressBlk = !isAddInvoiceAddressBlk;
};

const seeMoreLinkRegister = utils.get('see-more--link__register');
if(seeMoreLinkRegister)
    seeMoreLinkRegister.addEventListener('click', handleSeeMoreLinkRegisterClick);

const company = utils.get('company');
const first_name = utils.get('first_name');
const last_name = utils.get('last_name');
const email = utils.get('email');
const password = utils.get('password');
const submitBtn = utils.get('submit-btn');
const registerFrom = utils.get('register-form');

const validateInput = function (el) {
    if (el.checkValidity()) {
        return true;
    }
    else {
        el.focus();
        el.blur();
        return false;
    }
};

const submitForm = function (e) {
    e.preventDefault();

    let isValidForm = true;
    if (!validateInput(company))
        isValidForm = false;
    if (!validateInput(first_name))
        isValidForm = false;
    if (!validateInput(last_name))
        isValidForm = false;
    if (!validateInput(email))
        isValidForm = false;
    if (!validateInput(password))
        isValidForm = false;

    if (isValidForm)
        registerFrom.submit();
};

if (submitBtn)
    submitBtn.addEventListener('click', submitForm);
/* /handle register form ***************************************/

log('Ok, js is running!');