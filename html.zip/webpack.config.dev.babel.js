import merge from 'webpack-merge';
import {HotModuleReplacementPlugin} from 'webpack';
import ExtractTextPlugin from 'extract-text-webpack-plugin';
import common from './webpack.config.common.babel.js';

module.exports = merge(common, {
    context: __dirname + "/websrc",
    entry: [
        //'babel-polyfill',
        'webpack-dev-server/client?http://localhost:9010',
        'webpack/hot/only-dev-server',
        __dirname + '/websrc/js/js.js',
    ],
    output: {
        filename: 'js/js.js',
        path: __dirname + '/public',
    },
    devServer: {
        contentBase: __dirname + '/public',
        host: 'localhost',
        port: 9010,
        stats: {
            colors: true
        },
    },
    plugins: [
        new HotModuleReplacementPlugin(),
        new ExtractTextPlugin({
            filename: 'css/css.css',
            allChunks: true
        }),
    ]
});