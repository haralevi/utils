import ExtractTextPlugin from 'extract-text-webpack-plugin';
import path from 'path';

export default {
    resolve: {
        alias: {'@': path.resolve(__dirname, 'node_modules', '@material')},
        extensions: ['.scss', '.js']
    },
    module: {
        loaders: [{
            test: /\.js$/,
            loader: 'babel-loader',
            //exclude: /node_modules/
        }, {
            test: /\.scss$/,
            loader: ExtractTextPlugin.extract({
                fallback: 'style-loader',
                //use: ['css-loader', 'sass-loader']
                use: ['css-loader', 'sass-loader?{"includePaths":["./node_modules"]}']
            }),
            //exclude: /node_modules/
        }]
    }
}