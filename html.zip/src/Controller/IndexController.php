<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class IndexController extends Controller
{
    /**
     * @Route("/", name="index", methods={"GET"})
     * @return Response
     */
    public function index(): Response
    {
        /* @var $request Request */
        $request = $this->container->get('request_stack')->getCurrentRequest();

        $twigVar['page_type'] = $request->attributes->get('_route');

        $html = $this->renderView('index.html.twig', $twigVar);

        return new Response($html, Response::HTTP_OK, ['Content-Type' => 'text/html']);
    }
}

