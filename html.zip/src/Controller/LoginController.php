<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class LoginController extends Controller
{
    /**
     * @Route("/login", name="login", methods={"GET"})
     * @return Response
     */
    public function login(): Response
    {
        /* @var $request Request */
        $request = $this->container->get('request_stack')->getCurrentRequest();

        /* @var $authUtils AuthenticationUtils */
        $authUtils = $this->get('security.authentication_utils');

        // get the login error if there is one
        $error = $authUtils->getLastAuthenticationError();

        // last username entered by the user
        $lastUsername = $authUtils->getLastUsername();

        $twigVar['error'] = $error;
        $twigVar['last_username'] = $lastUsername;

        $twigVar['page_type'] = $request->attributes->get('_route');

        $html = $this->renderView('login.html.twig', $twigVar);

        return new Response($html, Response::HTTP_OK, ['Content-Type' => 'text/html']);
    }
}