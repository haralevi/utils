<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

class LangController extends Controller
{
    /**
     * @Route("/lang/{_locale}", name="lang", methods={"GET"}, requirements={"_locale"="en|fr|it|de"})
     * @return Response
     */
    public function lang(): Response
    {
        /* @var $request Request */
        $request = $this->container->get('request_stack')->getCurrentRequest();

        $locale = $request->getLocale();

        if (in_array($locale, array('en', 'fr', 'it', 'de'))) {
            $referer = $request->headers->get('referer');
            if (!empty($referer))
                return $this->redirect($referer);
            else
                return $this->redirectToRoute('index');
        } else {
            return $this->redirectToRoute('index');
        }
    }
}