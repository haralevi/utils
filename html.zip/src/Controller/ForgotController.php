<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class ForgotController extends Controller
{
    /**
     * @Route("/forgot", name="forgot", methods={"GET|POST"})
     * @return Response
     */
    public function forgot(): Response
    {
        /* @var $request Request */
        $request = $this->container->get('request_stack')->getCurrentRequest();

        $twigVar['page_type'] = $request->attributes->get('_route');

        $html = $this->renderView('forgot.html.twig', $twigVar);

        return new Response($html, Response::HTTP_OK, ['Content-Type' => 'text/html']);
    }
}