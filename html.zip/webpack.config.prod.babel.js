import merge from 'webpack-merge';
import UglifyJSPlugin from 'uglifyjs-webpack-plugin';
import ExtractTextPlugin from 'extract-text-webpack-plugin';
import common from './webpack.config.common.babel.js';
import {join} from 'path';

module.exports = merge(common, {
    context: __dirname + '/websrc',
    entry: [
        //'babel-polyfill',
        __dirname + '/websrc/js/js.js',
    ],
    output: {
        filename: 'js/js.js',
        path: __dirname + '/public',
    },
    plugins: [
        new ExtractTextPlugin({
            filename: 'css/css.css',
            allChunks: true,
        }),
        new UglifyJSPlugin(),
    ]
});