**PHP packages installation:**

$ composer update

**Clear cached files on production server:**

$ rm -rf /var/www/html/sp-admin-portal/var/cache/

$ rm -rf /var/www/html/sp-admin-portal/var/logs/

$ chmod -R 775 /var/www/html/sp-admin-portal/var/ 

**Unit testing:**

$ php /usr/local/bin/phpunit

**JS modules installation:**

$ yarn install
OR
$ yarn add --save-dev webpack webpack-merge clean-webpack-plugin inline-source-map webpack-dev-server babel-core babel-loader babel-preset-env sass-loader css-loader style-loader node-sass extract-text-webpack-plugin

$ npm install
OR
$ npm install --save-dev babel-polyfill babel-plugin-es6-promise babel-plugin-syntax-async-functions 

**Webpack usage:**

Starting webpack in development mode with hot-reloading:

$ yarn run start

Building *.js and *.css files for production:

$ yarn run build

**Starting PHP server locally:**

APPLICATION_ENV=dev php -S localhost:8888 -t public

**Apache configuration:**
```
<VirtualHost *:80>
    ServerName picxchange.net
    ServerAlias picxchange.net
    
    DocumentRoot /var/www/html/sp-admin-portal/public
    
    FallbackResource index.php
    
    <Directory "/var/www/html/sp-admin-portal/public">
        AllowOverride All
        Require all granted

        <IfModule mod_rewrite.c>
            Options -MultiViews

            RewriteEngine On

            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteRule ^(.+)\.\d+(\.(?:js|css))$ $1$2

            RewriteCond %{REQUEST_FILENAME} !-f
            RewriteRule ^(.*)$ index.php [QSA,L]
        </IfModule>

        <IfModule mod_deflate.c>
            AddOutputFilterByType DEFLATE text/plain
            AddOutputFilterByType DEFLATE text/html
            AddOutputFilterByType DEFLATE text/css
            AddOutputFilterByType DEFLATE text/javascript
            AddOutputFilterByType DEFLATE application/json
        </IfModule>
    </Directory>
</VirtualHost>
```

**Useful links:**

Webpack configuration:

https://webpack.js.org/guides/production/
