<?php

/* layout.html.twig */
class __TwigTemplate_1ef047f026b3833cbe8677ba4eff76f6a9d57f1ee5b8d2eee14fc4cdce94488f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <title>";
        // line 4
        $this->displayBlock('title', $context, $blocks);
        echo " - My Silex Application</title>
    <link href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
</head>
<body>

";
        // line 9
        $this->displayBlock('content', $context, $blocks);
        // line 10
        echo "
<script src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
</body>
</html>";
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 9,  49 => 4,  42 => 11,  39 => 10,  37 => 9,  30 => 5,  26 => 4,  21 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head>
    <title>{% block title '' %} - My Silex Application</title>
    <link href=\"{{ asset('css/main.css') }}\" rel=\"stylesheet\" type=\"text/css\"/>
</head>
<body>

{% block content %}{% endblock %}

<script src=\"{{ asset('js/main.js') }}\"></script>
</body>
</html>", "layout.html.twig", "D:\\phpstorm\\doopic\\templates\\layout.html.twig");
    }
}
