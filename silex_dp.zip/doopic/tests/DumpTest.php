<?php

use PHPUnit\Framework\TestCase;

class DumpTest extends TestCase
{
    public function testInitialPage()
    {
        $this->assertEquals(200, 200);
    }
}